﻿namespace CurrencyGraph.Extensions
{
    public static class DateTimeExtensions
    {
        // Calculate the start of the week based on the current date
        public static DateTime StartOfWeek(this DateTime dt)
        {
            int diff = (7 + (dt.DayOfWeek - DayOfWeek.Sunday)) % 7;
            return dt.AddDays(-1 * diff).Date;
        }
    }
}