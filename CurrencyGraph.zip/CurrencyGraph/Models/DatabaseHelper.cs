﻿using Microsoft.Data.Sqlite;

public class DatabaseHelper
{
    private const string ConnectionString = "Data Source=currency.db;";

    public static void CreateDatabaseIfNotExists()
    {
        using (var connection = new SqliteConnection(ConnectionString))
        {
            connection.Open();

            // SQL query to create the table if it doesn't exist
            string createTableQuery = @"
                CREATE TABLE IF NOT EXISTS CurrencyGraphs (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    CurrencyCode TEXT NOT NULL,
                    CurrencyName TEXT NOT NULL,
                    ExchangeRate REAL NOT NULL,
                    LastUpdated TEXT NOT NULL
                );";

            using (var command = new SqliteCommand(createTableQuery, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}