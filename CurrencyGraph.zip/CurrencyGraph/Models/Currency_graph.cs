﻿namespace CurrencyGraph.Models
{
    public class Currency_graph
    {
        public int Id { get; set; } // Primary key
        public string CurrencyCode { get; set; } // Currency code (e.g., USD)
        public string CurrencyName { get; set; } // Currency name (e.g., Dollar, Pound)

        public double ExchangeRate { get; set; } // Exchange rate value
        public DateTime LastUpdated { get; set; } // Last update timestamp
    }
}
