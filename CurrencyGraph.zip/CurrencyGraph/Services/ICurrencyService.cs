﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurrencyGraph.Models;

namespace CurrencyGraph.Services
{
    public interface ICurrencyService
    {
        /// <summary>
        /// שליפת נתוני המטבעות מה-API של בנק ישראל ועדכון מסד הנתונים.
        /// </summary>
        Task FetchAndStoreCurrencyGraphAsync();

        /// <summary>
        /// שליפת נתוני המטבעות מהשנה האחרונה עבור מטבעות נתמכים.
        /// </summary>
        /// <returns>רשימה של נתוני מטבעות מהשנה האחרונה.</returns>
        Task<List<Currency_graph>> GetCurrencyDataForLastYearAsync();
    }
}
