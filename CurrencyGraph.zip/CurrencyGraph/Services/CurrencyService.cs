﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using CurrencyGraph.Data;
using CurrencyGraph.Models;
using Microsoft.EntityFrameworkCore;

namespace CurrencyGraph.Services
{
    public class CurrencyService : ICurrencyService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string[] _supportedCurrencies = { "USD", "GBP", "SEK", "CHF" }; // מטבעות נתמכים

        private const string CurrencyApiUrl = "https://www.boi.org.il/PublicApi/GetExchangeRates"; // URL של ה-API

        public CurrencyService(ApplicationDbContext dbContext, IHttpClientFactory httpClientFactory)
        {
            _dbContext = dbContext;
            _httpClientFactory = httpClientFactory;
        }

        /// <summary>
        /// שליפה ועדכון נתוני המטבעות
        /// </summary>
        public async Task FetchAndStoreCurrencyGraphAsync()
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                var response = await client.GetStringAsync(CurrencyApiUrl);

                Console.WriteLine("Response from API:");
                Console.WriteLine(response);

                // פענוח JSON לנתונים מותאמים
                var exchangeRates = ParseCurrencyData(response);

                foreach (var rate in exchangeRates)
                {
                    var existingRecord = await _dbContext.CurrencyGraphs
                        .FirstOrDefaultAsync(c => c.CurrencyCode == rate.CurrencyCode && c.LastUpdated.Date == rate.LastUpdated.Date);

                    if (existingRecord == null)
                    {
                        _dbContext.CurrencyGraphs.Add(rate);
                    }
                    else
                    {
                        existingRecord.ExchangeRate = rate.ExchangeRate;
                        existingRecord.LastUpdated = rate.LastUpdated;
                    }
                }

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error fetching and storing currency data.", ex);
            }
        }

        /// <summary>
        /// פענוח JSON מה-API לרשימת אובייקטים מותאמים
        /// </summary>
        private List<Currency_graph> ParseCurrencyData(string jsonData)
        {
            if (string.IsNullOrEmpty(jsonData))
                throw new ArgumentException("Received empty or null JSON data.");

            try
            {
                var response = JsonSerializer.Deserialize<ExchangeRatesResponse>(jsonData);

                if (response?.ExchangeRates == null)
                    throw new InvalidOperationException("Failed to parse exchange rates.");

                return response.ExchangeRates
                    .Where(rate => _supportedCurrencies.Contains(rate.Key)) // סינון מטבעות נתמכים
                    .Select(rate => new Currency_graph
                    {
                        CurrencyCode = rate.Key,
                        ExchangeRate = rate.CurrentExchangeRate,
                        LastUpdated = DateTime.Parse(rate.LastUpdate)
                    })
                    .ToList();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error parsing JSON data.", ex);
            }
        }

        /// <summary>
        /// שליפת נתונים מהשנה האחרונה
        /// </summary>
        public async Task<List<Currency_graph>> GetCurrencyDataForLastYearAsync()
        {
            var oneYearAgo = DateTime.Now.AddYears(-1);

            return await _dbContext.CurrencyGraphs
                .Where(c => _supportedCurrencies.Contains(c.CurrencyCode) && c.LastUpdated >= oneYearAgo)
                .OrderBy(c => c.LastUpdated)
                .ToListAsync();
        }
    }

    // מחלקת JSON מותאמת
    public class ExchangeRatesResponse
    {
        public List<ExchangeRate> ExchangeRates { get; set; }
    }

    public class ExchangeRate
    {
        public string Key { get; set; } // קוד מטבע
        public double CurrentExchangeRate { get; set; } // שער חליפין
        public string LastUpdate { get; set; } // תאריך עדכון
    }
}
