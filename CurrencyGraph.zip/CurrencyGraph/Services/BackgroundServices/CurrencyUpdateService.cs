﻿using CurrencyGraph.Services;
using CurrencyGraph.Data;
using CurrencyGraph.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyGraph.BackgroundServices
{
    public class CurrencyUpdateService : IHostedService, IDisposable
    {
        private readonly ILogger<CurrencyUpdateService> _logger;
        private readonly IServiceProvider _serviceProvider; // הוספנו את ה- IServiceProvider
        private Timer _timer;

        public CurrencyUpdateService(ILogger<CurrencyUpdateService> logger, IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider; // הזרקת ה- IServiceProvider
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Currency Update Service starting.");

            // עדכון נתונים כל שעה
            _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromHours(1));

            return Task.CompletedTask;
        }

        private async void DoWork(object state)
        {
            try
            {
                _logger.LogInformation("Fetching and storing currency data...");

                // שליפת נתונים חדשים ועדכון למסד נתונים
                using (var scope = _serviceProvider.CreateScope()) // יצירת Scope חדש
                {
                    var currencyService = scope.ServiceProvider.GetRequiredService<CurrencyService>();
                    await currencyService.FetchAndStoreCurrencyGraphAsync(); // קריאה לפונקציה לעדכון הנתונים
                }

                // הסרת נתונים ישנים יותר משנה
                CleanOldCurrencyData();

                _logger.LogInformation("Currency data updated.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while updating currency data: {ex.Message}");
            }
        }

        private void CleanOldCurrencyData()
        {
            var oneYearAgo = DateTime.Now.AddYears(-1);

            // מחיקת נתונים ישנים יותר משנה
            using (var scope = _serviceProvider.CreateScope()) // יצירת Scope חדש לגישה למסד הנתונים
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                var oldData = dbContext.CurrencyGraphs
                    .Where(r => r.LastUpdated < oneYearAgo)
                    .ToList();

                if (oldData.Any())
                {
                    dbContext.CurrencyGraphs.RemoveRange(oldData);
                    dbContext.SaveChanges();
                    _logger.LogInformation($"Removed {oldData.Count} old currency records.");
                }
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Currency Update Service stopping.");
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
