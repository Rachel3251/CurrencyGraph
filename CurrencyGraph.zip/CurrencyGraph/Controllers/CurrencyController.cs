﻿namespace CurrencyGraph.Controllers
{
    using CurrencyGraph.Data;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Linq;
    using CurrencyGraph.Services;
    using CurrencyGraph.Extensions;

    [ApiController]
    [Route("api/[controller]")]
    public class CurrencyController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly CurrencyService _currencyService;

        public CurrencyController(ApplicationDbContext dbContext, CurrencyService currencyService)
        {
            _dbContext = dbContext;
            _currencyService = currencyService;
        }

        // Endpoint to fetch and store currency data
        [HttpPost("fetch")]
        public async Task<IActionResult> FetchAndStoreData()
        {
            await _currencyService.FetchAndStoreCurrencyGraphAsync();
            return Ok("Currency data fetched and stored successfully.");
        }

        // Endpoint to retrieve currency graphs based on a specified period
        [HttpGet("currency-graph")]
        public IActionResult GetCurrencyGraphs([FromQuery] string period)
        {
            var validPeriods = new[] { "week", "month", "halfyear", "year" };
            if (!validPeriods.Contains(period.ToLower()))
            {
                return BadRequest("Invalid period. Please provide one of the following: week, month, halfyear, year.");
            }

            DateTime fromDate = GetStartDate(period.ToLower());

            // שליפת הנתונים מתוך המסד לפי התקופה שהמשתמש בחר
            var graphs = _dbContext.CurrencyGraphs
          .Where(r => r.LastUpdated >= fromDate)  // סינון לפי התקופה
          .GroupBy(r => new { r.CurrencyCode, r.CurrencyName })  // קבוצת מטבעות
          .Select(g => new
          {
              Currency = g.Key.CurrencyName,
              CurrencyCode = g.Key.CurrencyCode,
              Values = g.OrderBy(x => x.LastUpdated)  // מיין את הערכים לפי התאריך
                  .Select(x => new
                  {
                      x.LastUpdated,
                      x.ExchangeRate
                  })
                  .ToList()  // חזור עם רשימה של כל הנתונים לכל מטבע
          })
          .ToList();


            return Ok(graphs);
        }

        // Endpoint to print all currency graphs
        [HttpGet("print")]
        public IActionResult PrintCurrencyGraphs()
        {
            var data = _dbContext.CurrencyGraphs.ToList();

            if (data.Count == 0)
            {
                return Ok("No data found in CurrencyGraphs table.");
            }

            // Format the data for output
            var result = data.Select(graph => new
            {
                Currency = graph.CurrencyName,
                ExchangeRate = graph.ExchangeRate,
                LastUpdated = graph.LastUpdated
            });

            return Ok(result);
        }

        // Helper method to remove old data beyond a year
        [HttpDelete("remove-old")]
        public void RemoveOldCurrencyData()
        {
            var oneYearAgo = DateTime.Now.AddYears(-1);
            var oldData = _dbContext.CurrencyGraphs
                .Where(r => r.LastUpdated < oneYearAgo)
                .ToList();

            if (oldData.Any())
            {
                _dbContext.CurrencyGraphs.RemoveRange(oldData);
                _dbContext.SaveChanges();
            }
        }
        [HttpGet("currency-last-year")]
        public async Task<IActionResult> GetCurrencyDataForLastYear()
        {
            try
            {
                var currencyData = await _currencyService.GetCurrencyDataForLastYearAsync();

                if (currencyData == null || !currencyData.Any())
                {
                    return NotFound("No data found for the requested period.");
                }

                return Ok(currencyData);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("all-currency-graphs")]
        public IActionResult GetAllCurrencyGraphs()
        {
            // שליפת כל הנתונים מתוך טבלת CurrencyGraphs
            var data = _dbContext.CurrencyGraphs.ToList();

            // אם אין נתונים, תחזיר תשובה מתאימה
            if (!data.Any())
            {
                return NotFound("No data found in CurrencyGraphs table.");
            }

            // החזרת כל הנתונים
            return Ok(data);
        }

        private DateTime GetStartDate(string period)
        {
            switch (period)
            {
                case "week":
                    return DateTime.Now.AddDays(-7);  // 7 ימים אחורה
                case "month":
                    return DateTime.Now.AddMonths(-1);  // חודש אחורה
                case "halfyear":
                    return DateTime.Now.AddMonths(-6);  // חצי שנה אחורה
                case "year":
                    return DateTime.Now.AddYears(-1);  // שנה אחורה
                default:
                    return DateTime.Now;  // ברירת מחדל במקרה של טעות
            }
        }
    }
}
