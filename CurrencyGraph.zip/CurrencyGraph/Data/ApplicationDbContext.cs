﻿namespace CurrencyGraph.Data
{
    using CurrencyGraph.Models;
    using Microsoft.EntityFrameworkCore;

    public class ApplicationDbContext : DbContext
    {
        public DbSet<Currency_graph> CurrencyGraphs { get; set; }

        // הוספת קונסטרוקטור שמקבל DbContextOptions ומעביר אותו לבסיס
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure primary key
            modelBuilder.Entity<Currency_graph>()
                .HasKey(c => c.Id);

            // Set maximum length for the CurrencyCode column
            modelBuilder.Entity<Currency_graph>()
                .Property(c => c.CurrencyCode)
                .HasMaxLength(3);

            // Set maximum length for the CurrencyName column
            modelBuilder.Entity<Currency_graph>()
                .Property(c => c.CurrencyName)
                .HasMaxLength(50);

            // Ensure ExchangeRate is required
            modelBuilder.Entity<Currency_graph>()
                .Property(c => c.ExchangeRate)
                .IsRequired();

            // אם CurrencyName חייב להיות לא NULL, אפשר גם להוסיף את ההגבלה הזו
            modelBuilder.Entity<Currency_graph>()
                .Property(c => c.CurrencyName)
                .IsRequired();
        }
    }
}
